# Affichage_Horaires
Application web d'affichage dynamique des horaires en gare SNCF et à l'aéroport Lorraine.


## Utilisation 

### url services 
L'application est acctuellement fonctionnelle sur l'url :
https://exemple.com/affichages_horaires?train_dep=1&train_arr=1&vol_dep=1&vol_arr=1&code_gare=NCY

Les paramètres de l'url sont les suivants : 

##### 1ér paramètre : train_dep : 
    - train_dep = 1 ==> affiche le tableau des horaires de trains de départ.
    - train_dep = 0 ==> n'affiche pas le tableau des horaires de trains de départ.
##### 2ème paramètre : train_arr : 
    - train_arr = 1 ==> affiche le tableau des horaires de trains d'arrivée.
    - train_arr = 0 ==> n'affiche pas le tableau des horaires de trains d'arrivée.
##### 3ème paramètre : train_arr : 
    - vol_dep = 1 ==> affiche le tableau des horaires de départ à l'aéroport Lorraine.
    - vol_dep = 0 ==> n'affiche pas le tableau des horaires de départ à l'aéroport Lorraine.
##### 4ème paramètre : train_arr : 
    - vol_arr = 1 ==> affiche le tableau des horaires d'arrivée à l'aéroport Lorraine.
    - vol_arr = 0 ==> n'affiche pas le tableau des horaires d'arrivée à l'aéroport Lorraine.
##### 5ème paramètre : code_gare : 
    - code_gare = ncy : ce paramètre permet de choisir le nom de la gare qui ne doit pas dépasser 3 lettres, par exemple : ncy (Nancy) + Jarv (Jarville) + Strasbourg (str)

On peut donc choisir le tableau à afficher depuis les paramètres de l'url.