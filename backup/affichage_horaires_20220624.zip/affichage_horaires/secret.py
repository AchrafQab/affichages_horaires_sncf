### PROXY ###
# https_proxy="http://f.broussais:Salete_21@sproxy.gnancy.local:8080"
# http_proxy="http://f.broussais:Salete_21@sproxy.gnancy.local:8080"
https_proxy = ""
http_proxy = ""
# http_proxy="http://sproxy/proxy.pac"
# https_proxy="https://sproxy/proxy.pac"

login = ""
password= ""